<?php
/**
 * Astra Child Theme Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra Child Theme
 * @since 1.0.0
 */

/**
 * Define Constants
 */
define( 'ASTRA_CHILD_THEME_VERSION', '1.0.0' );

/**
 * Enqueue styles
 */
function child_enqueue_styles() {

	wp_enqueue_style( 'astra-child-theme-css', get_stylesheet_directory_uri() . '/style.css', array('astra-theme-css'), ASTRA_CHILD_THEME_VERSION, 'all' );

}

/** 
 * Enqueue scripts
 */
function child_enqueue_scripts() {

    wp_enqueue_script( 'jquery-effects-core' );
    wp_enqueue_script( 'astra-child-theme-main-js', get_stylesheet_directory_uri() . '/main.js', array( 'jquery' ), ASTRA_CHILD_THEME_VERSION, true );
    
}

add_action( 'wp_enqueue_scripts', 'child_enqueue_styles', 15 );
add_action( 'wp_enqueue_scripts', 'child_enqueue_scripts', 15 );

/** 
 * Add Cache Cookie
 */
add_action( 'init', 'em_admin_cookie' );
function em_admin_cookie() {
    if ( current_user_can( 'manage_options' ) ) {
        if ( !isset( $_COOKIE[ 'wordpress_admin_logged_in' ] ) ) {
            setcookie( 'wordpress_admin_logged_in', 1, 0, COOKIEPATH, COOKIE_DOMAIN, false );
        }
    }
}